let subjects = [
  {
    category: "biology",
    value: "Biology",
  },

];

export default function getSubjects() {
  return subjects;
}
