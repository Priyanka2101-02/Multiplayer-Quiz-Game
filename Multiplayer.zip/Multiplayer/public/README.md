# Solotov
Jogo de perguntas e respostas voltado ao ensino em Moçambique